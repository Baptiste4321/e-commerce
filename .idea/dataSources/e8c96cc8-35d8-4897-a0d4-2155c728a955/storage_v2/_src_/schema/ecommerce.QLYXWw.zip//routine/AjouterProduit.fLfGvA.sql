create
    definer = root@localhost procedure AjouterProduit(IN p_Nom varchar(255), IN p_Description text,
                                                      IN p_Prix decimal(10, 2), IN p_Stock_disponible int)
BEGIN
    DECLARE isAdmin VARCHAR(50);
    SET isAdmin = (SELECT Type_utilisateur FROM Utilisateur WHERE Mail = CURRENT_USER);

    IF isAdmin = 'admin' THEN
        INSERT INTO Produit (Nom, Description, Prix, Stock_disponible)
        VALUES (p_Nom, p_Description, p_Prix, p_Stock_disponible);
ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Vous n''avez pas les droits pour effectuer cette opération.';
END IF;
END;

