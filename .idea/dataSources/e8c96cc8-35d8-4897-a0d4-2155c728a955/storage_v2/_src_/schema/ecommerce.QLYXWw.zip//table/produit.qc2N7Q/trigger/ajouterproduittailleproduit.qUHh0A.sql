create definer = root@localhost trigger AjouterProduitTailleProduit
    after insert
    on produit
    for each row
BEGIN
    -- Ajouter une entrée dans la table Taille_produit pour la taille par défaut 'L' avec une quantité par défaut de 10
    INSERT INTO Taille_produit (ID_produit, Taille, Stock_disponible) VALUES (NEW.ID_produit, 'L', 10);
END;

