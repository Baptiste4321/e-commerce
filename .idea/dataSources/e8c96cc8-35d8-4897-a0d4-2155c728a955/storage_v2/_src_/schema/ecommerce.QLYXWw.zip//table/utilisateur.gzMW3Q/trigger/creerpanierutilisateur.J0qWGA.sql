create definer = root@localhost trigger CreerPanierUtilisateur
    after insert
    on utilisateur
    for each row
BEGIN
    INSERT INTO Panier (Mail, Date_creation) VALUES (NEW.Mail, NOW());
END;

